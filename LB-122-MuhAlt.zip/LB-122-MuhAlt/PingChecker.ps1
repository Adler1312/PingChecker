﻿Add-Type -AssemblyName PresentationFramework  # Für MessageBox

# ==== KONFIGURATION ====
$ipFile = "C:\giri\ip.txt"
$logFile = "C:\giri\result.txt"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
# ========================

# ==== IP-Adressen laden ====
if (!(Test-Path $ipFile)) {
    [System.Windows.MessageBox]::Show("IP-Datei nicht gefunden: $ipFile", "Fehler", "OK", "Error")
    exit
}
$ipList = Get-Content $ipFile

# ==== Log-Datei vorbereiten ====
"`n==== Ping-Test gestartet am $timestamp ====" | Out-File -FilePath $logFile -Append

# ==== Jede IP pingen ====
foreach ($ip in $ipList) {
    $result = Test-Connection -ComputerName $ip -Count 4 -Quiet

    if (-not $result) {
        # Optional: Detaillierter Ping
        $pingOutput = ping $ip
        if ($pingOutput -match "100% loss") {
            $entry = "$ip - 100% FAILED (nicht erreichbar)"
            [System.Windows.MessageBox]::Show("Fehler: $entry", "Ping Fehler", "OK", "Error")
        } else {
            $entry = "$ip - Teilweise fehlgeschlagen oder keine Antwort"
        }
    } else {
        $entry = "$ip - SUCCESS (erreichbar)"
    }

    $entry | Out-File -FilePath $logFile -Append
    Write-Host $entry
}
